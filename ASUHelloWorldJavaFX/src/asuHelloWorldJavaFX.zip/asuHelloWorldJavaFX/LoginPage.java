package asuHelloWorldJavaFX;

import java.time.LocalDate;


public class LoginPage 
{
	protected String fName, lName;
	protected int DOB;
	
	public boolean loggedIn(String fn, String ln, LocalDate doB) {
		return true;
	}
}